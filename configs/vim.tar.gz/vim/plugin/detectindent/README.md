Code from https://github.com/ciaranm/detectindent/tree/master/plugin

It basically never gets updated there, which is fine.

import styled from 'styled-components';

const Div = styled.div`
  font-family: 'Times New Roman', serif;
`;

const P = styled.p`
  font-family: Arial, sans-serif;
  font-family: Arial, 'sans-serif';
`;

const A = styled.a`
  font-family: system-ui;
`;

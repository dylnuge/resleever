///<reference path="./some-module.ts" />

"use strict";
class TestClass {
}

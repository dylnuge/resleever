export var someVar: any = null;
export var altVar: any = null;

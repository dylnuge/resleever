import { someVar } from './some-module';
import { altVar } from './some-module';

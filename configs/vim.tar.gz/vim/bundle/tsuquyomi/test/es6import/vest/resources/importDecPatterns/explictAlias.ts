import { someVar as _var } from './some-module';
import * as $var from './some-module';

module SignatureHelpTest {
  export class Calc {
    /**
     *
     * An add method.
     * It's is useful for calc.
     * @param a A operand.
     *          It is the first operand.
     * @param b Another operand.
     * @returns Summation of a and b.
     *
     **/
    add(a: number, b: number): number {
      return a + b;
    }
  }

  var calc = new Calc();
  calc.add( 
}

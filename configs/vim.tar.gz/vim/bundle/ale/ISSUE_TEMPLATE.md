<!--
    This is a template for bug reports. If you want to request a new feature,
    you can clear this entire form field and write a short description of what
    you want.
-->

## Information

**VIM version**

PASTE JUST THE FIRST TWO LINES OF `:version` HERE.

Operating System: WHAT OS WERE YOU USING?

### :ALEInfo

PASTE OUTPUT OF `:ALEInfo` HERE. YOU CAN TRY `:ALEInfoToClipboard`.

## What went wrong

WRITE WHAT WENT WRONG HERE.

## Reproducing the bug

Steps for repeating the bug:

1. Write a list of steps.
2. Otherwise nobody will fix the bug.
